<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NameForm extends Model
{
    //
}
