<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DNIType extends Model
{
    //
}
