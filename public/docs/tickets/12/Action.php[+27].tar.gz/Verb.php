<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Verb extends Model
{
    //
}
